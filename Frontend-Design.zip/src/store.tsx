import { createContext, useContext, useEffect, useMemo, useReducer, useState } from "react";

export type VisitStatus = "Completada" | "En curso" | "Con novedad" | "Pendiente" | "Vencida" | "Validada";
export type NoveltyStatus = "Registrada" | "Notificada" | "En revisión" | "En acción" | "Resuelta" | "Cerrada" | "Reabierta";
export type Priority = "Crítica" | "Alta" | "Media" | "Baja";
export type Supervisor = { id: string; name: string; initials: string; active: boolean; phone: string; compliance: number; last: string };
export type Center = { id: string; name: string; client: string; address: string; radius: number; frequency: string; supervisorId: string; activities: string[] };
export type Visit = { id: string; centerId: string; supervisorId: string; date: string; time: string; checkout?: string; status: VisitStatus; sync: string; geo: number; notes?: string };
export type HistoryEntry = { status: NoveltyStatus; author: string; at: string; comment: string };
export type Novelty = { id: string; title: string; centerId: string; supervisorId: string; visitId: string; priority: Priority; status: NoveltyStatus; description: string; history: HistoryEntry[] };
export type Alert = { id: string; title: string; detail: string; type: string; severity: "Crítica" | "Alta" | "Media"; origin: string; attended: boolean; attendedAt?: string };
export type Evidence = { id: string; centerId: string; supervisorId: string; visitId: string; type: string; at: string; hash: string; verified: boolean };
export type Settings = { radius: number; minDuration: number; gpsAccuracy: number; autoAlerts: boolean; email: boolean; push: boolean; networkError: boolean; slow: boolean };
export type AppState = {
  session: { loggedIn: boolean; name: string; email: string };
  supervisors: Supervisor[]; centers: Center[]; visits: Visit[]; novelties: Novelty[]; alerts: Alert[]; evidence: Evidence[]; settings: Settings;
};

const today = new Date().toLocaleDateString("en-CA", { timeZone: "America/Bogota" });
const isoNow = () => new Date().toISOString();
const supNames = ["Laura Gómez", "Carlos Ruiz", "Andrea Melo", "Miguel Torres", "Valentina Rojas", "Daniel Castro", "Natalia León", "Jorge Díaz", "Paula Vargas", "Esteban Gil", "María Cano", "Felipe Mora"];
const centersSeed: Center[] = [
  { id: "c1", name: "Torre Empresarial 93", client: "Grupo Andino", address: "Cra. 13 #93-40, Bogotá", radius: 120, frequency: "Diaria", supervisorId: "s1", activities: ["Lobby y zonas comunes", "Baños pisos 1–5", "Manejo de residuos"] },
  { id: "c2", name: "Conjunto Bosques del Norte", client: "Administraciones UNO", address: "Calle 153 #18-22, Bogotá", radius: 150, frequency: "Lun–Mié–Vie", supervisorId: "s2", activities: ["Zonas verdes", "Piscina", "Parqueaderos"] },
  { id: "c3", name: "Centro Comercial Altavista", client: "Retail Colombia", address: "Carrera 7 #140-20, Bogotá", radius: 200, frequency: "Diaria", supervisorId: "s3", activities: ["Fachada", "Baños públicos", "Cuarto de aseo"] },
  { id: "c4", name: "Edificio Parque Central", client: "Inversiones Capital", address: "Calle 72 #10-34, Bogotá", radius: 100, frequency: "Semanal", supervisorId: "s4", activities: ["Lobby", "Ascensores", "Escaleras"] },
  { id: "c5", name: "Clínica San Rafael", client: "Red Salud", address: "Cra. 8 #17-45, Bogotá", radius: 80, frequency: "Diaria", supervisorId: "s1", activities: ["Áreas críticas", "Recepción", "Residuos biosanitarios"] },
];
const supervisorsSeed: Supervisor[] = supNames.map((name, i) => ({
  id: `s${i + 1}`, name, initials: name.split(" ").map((part) => part[0]).join("").slice(0, 2), active: i < 9,
  phone: `300 555 ${String(1100 + i)}`, compliance: [96, 91, 78, 88, 94, 86, 90, 83, 97, 74, 79, 81][i], last: i < 9 ? `Hace ${i * 4 + 2} min` : "Hace 3 días",
}));
const statuses: VisitStatus[] = ["Completada", "En curso", "Con novedad", "Pendiente", "Vencida"];
const visitsSeed: Visit[] = Array.from({ length: 38 }, (_, i) => ({
  id: `v${i + 1}`, centerId: `c${(i % 5) + 1}`, supervisorId: `s${(i % 9) + 1}`, date: today,
  time: `${String(7 + Math.floor(i / 6)).padStart(2, "0")}:${String((i * 10) % 60).padStart(2, "0")}`,
  checkout: i % 5 === 0 ? "09:10" : undefined, status: statuses[i % 5], sync: i % 9 === 0 ? "Pendiente" : "Sincronizado", geo: i % 7 === 2 ? 340 : 12 + (i % 18),
}));
const noveltyTitles = ["Baños públicos sin insumos", "Piscina con residuos", "Falta dotación del personal", "Luminaria dañada", "Piso húmedo sin señalizar", "Cuarto de aseo sin cierre", "Retraso del operario", "Insumos mal almacenados", "Vidrio exterior manchado", "Ascensor con residuos", "Caneca sin tapa", "Olor en zona común"];
const noveltyStates: NoveltyStatus[] = ["Registrada", "Notificada", "En revisión", "En acción", "Resuelta", "Cerrada"];
const priorities: Priority[] = ["Crítica", "Alta", "Media", "Baja"];
const noveltiesSeed: Novelty[] = noveltyTitles.map((title, i) => ({
  id: `n${i + 1}`, title, centerId: `c${(i % 5) + 1}`, supervisorId: `s${(i % 9) + 1}`, visitId: `v${i + 1}`, priority: priorities[i % 4],
  status: noveltyStates[i % 6], description: `Se identificó ${title.toLowerCase()} durante la supervisión. Se requiere seguimiento del coordinador.`,
  history: [{ status: "Registrada", author: supervisorsSeed[i % 9].name, at: isoNow(), comment: "Novedad registrada desde la visita." }],
}));
const alertTypes = ["Visita no iniciada", "Check-in fuera de geocerca", "Check-out sin cerrar", "Visita demasiado corta", "Novedad crítica", "Sincronización fallida"];
const alertsSeed: Alert[] = Array.from({ length: 10 }, (_, i) => ({
  id: `a${i + 1}`, title: alertTypes[i % 6], detail: `${supervisorsSeed[i % 9].name} · ${centersSeed[i % 5].name}`, type: alertTypes[i % 6],
  severity: i % 3 === 0 ? "Crítica" : i % 3 === 1 ? "Alta" : "Media", origin: i % 6 === 4 ? `/novedades/n${(i % 12) + 1}` : `/visitas/v${i + 1}`, attended: i > 6,
}));
const evidenceSeed: Evidence[] = Array.from({ length: 30 }, (_, i) => ({
  id: `e${i + 1}`, centerId: `c${(i % 5) + 1}`, supervisorId: `s${(i % 9) + 1}`, visitId: `v${(i % 38) + 1}`,
  type: ["Llegada", "Actividad", "Novedad"][i % 3], at: isoNow(), hash: `a4f9c20e8d7b${String(i).padStart(4, "0")}73bc91f2`, verified: i % 7 !== 0,
}));

export const seedState: AppState = {
  session: { loggedIn: true, name: "Sofía Martínez", email: "sofia@supervisa.co" },
  supervisors: supervisorsSeed, centers: centersSeed, visits: visitsSeed, novelties: noveltiesSeed, alerts: alertsSeed, evidence: evidenceSeed,
  settings: { radius: 100, minDuration: 20, gpsAccuracy: 30, autoAlerts: true, email: true, push: true, networkError: false, slow: false },
};

type Action =
  | { type: "LOGIN" } | { type: "LOGOUT" } | { type: "RESET" }
  | { type: "ADD_VISIT"; visit: Visit }
  | { type: "ATTEND_ALERT"; id: string; attended: boolean }
  | { type: "ATTEND_ALL" }
  | { type: "UPDATE_NOVELTY"; id: string; status: NoveltyStatus; comment: string }
  | { type: "UPDATE_VISIT"; id: string; patch: Partial<Visit> }
  | { type: "UPDATE_CENTER"; id: string; patch: Partial<Center> }
  | { type: "UPDATE_SETTINGS"; settings: Settings };

function reducer(state: AppState, action: Action): AppState {
  if (action.type === "LOGIN") return { ...state, session: { ...state.session, loggedIn: true } };
  if (action.type === "LOGOUT") return { ...state, session: { ...state.session, loggedIn: false } };
  if (action.type === "RESET") return seedState;
  if (action.type === "ADD_VISIT") return { ...state, visits: [action.visit, ...state.visits] };
  if (action.type === "ATTEND_ALERT") return { ...state, alerts: state.alerts.map((a) => a.id === action.id ? { ...a, attended: action.attended, attendedAt: action.attended ? isoNow() : undefined } : a) };
  if (action.type === "ATTEND_ALL") return { ...state, alerts: state.alerts.map((a) => ({ ...a, attended: true, attendedAt: isoNow() })) };
  if (action.type === "UPDATE_NOVELTY") return { ...state, novelties: state.novelties.map((n) => n.id === action.id ? { ...n, status: action.status, history: [...n.history, { status: action.status, author: state.session.name, at: isoNow(), comment: action.comment }] } : n) };
  if (action.type === "UPDATE_VISIT") return { ...state, visits: state.visits.map((v) => v.id === action.id ? { ...v, ...action.patch } : v) };
  if (action.type === "UPDATE_CENTER") return { ...state, centers: state.centers.map((c) => c.id === action.id ? { ...c, ...action.patch } : c) };
  if (action.type === "UPDATE_SETTINGS") return { ...state, settings: action.settings };
  return state;
}

type StoreValue = { state: AppState; dispatch: React.Dispatch<Action> };
const StoreContext = createContext<StoreValue | null>(null);
const ToastContext = createContext<{ push: (message: string, action?: { label: string; run: () => void }) => void } | null>(null);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, seedState, (seed) => {
    try { return JSON.parse(localStorage.getItem("supervisa-store") || "") as AppState; } catch { return seed; }
  });
  useEffect(() => { try { localStorage.setItem("supervisa-store", JSON.stringify(state)); } catch { /* storage can be unavailable */ } }, [state]);
  return <StoreContext.Provider value={{ state, dispatch }}>{children}</StoreContext.Provider>;
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<{ id: number; message: string; action?: { label: string; run: () => void } }[]>([]);
  const value = useMemo(() => ({ push: (message: string, action?: { label: string; run: () => void }) => {
    const id = Date.now(); setToasts((old) => [...old.slice(-2), { id, message, action }]);
    window.setTimeout(() => setToasts((old) => old.filter((toast) => toast.id !== id)), 4000);
  } }), []);
  return <ToastContext.Provider value={value}>{children}<div className="toast-stack" role="status">{toasts.map((toast) => <div className="toast" key={toast.id}><span>{toast.message}</span>{toast.action && <button onClick={() => { toast.action?.run(); setToasts((old) => old.filter((item) => item.id !== toast.id)); }}>{toast.action.label}</button>}<button aria-label="Cerrar" onClick={() => setToasts((old) => old.filter((item) => item.id !== toast.id))}>×</button></div>)}</div></ToastContext.Provider>;
}

export function useStore() { const value = useContext(StoreContext); if (!value) throw new Error("StoreProvider requerido"); return value; }
export function useToast() { const value = useContext(ToastContext); if (!value) throw new Error("ToastProvider requerido"); return value; }
export function useMetrics() {
  const { state } = useStore();
  return {
    completed: state.visits.filter((v) => v.status === "Completada" || v.status === "Validada").length,
    pending: state.visits.filter((v) => v.status === "Pendiente" || v.status === "Vencida").length,
    activeSupervisors: state.supervisors.filter((s) => s.active).length,
    compliance: Math.round(state.supervisors.reduce((sum, s) => sum + s.compliance, 0) / state.supervisors.length * 10) / 10,
    openNovelties: state.novelties.filter((n) => n.status !== "Cerrada").length,
    criticalNovelties: state.novelties.filter((n) => n.status !== "Cerrada" && n.priority === "Crítica").length,
    unattendedAlerts: state.alerts.filter((a) => !a.attended).length,
  };
}

export const formatDate = (date = new Date()) => new Intl.DateTimeFormat("es-CO", { timeZone: "America/Bogota", day: "2-digit", month: "long", year: "numeric" }).format(date);
export const noveltyFlow: NoveltyStatus[] = ["Registrada", "Notificada", "En revisión", "En acción", "Resuelta", "Cerrada"];
