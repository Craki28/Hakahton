import { useEffect, useRef } from "react";
import { AlertTriangle, CheckCircle2, Inbox, X } from "lucide-react";

export function Avatar({ initials, small = false }: { initials: string; small?: boolean }) {
  return <span className={`avatar ${small ? "avatar-small" : ""}`}>{initials}</span>;
}

export function StatusChip({ children, tone = "neutral" }: { children: React.ReactNode; tone?: string }) {
  return <span className={`status-chip ${tone}`}><span className="status-dot" />{children}</span>;
}

export function PageHeader({ eyebrow, title, description, children }: { eyebrow?: string; title: string; description: string; children?: React.ReactNode }) {
  return <div className="page-heading"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h1>{title}</h1><p>{description}</p></div>{children && <div className="heading-actions">{children}</div>}</div>;
}

export function Modal({ title, children, onClose, wide = false }: { title: string; children: React.ReactNode; onClose: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const close = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    document.addEventListener("keydown", close); ref.current?.focus();
    return () => document.removeEventListener("keydown", close);
  }, [onClose]);
  return <div className="modal-layer" onMouseDown={(event) => event.target === event.currentTarget && onClose()}><div className={`modal-card ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} ref={ref}><div className="modal-heading"><h2>{title}</h2><button className="icon-button" aria-label="Cerrar" onClick={onClose}><X size={19} /></button></div>{children}</div></div>;
}

export function EmptyState({ title = "No hay resultados", text = "Prueba cambiando los filtros.", action }: { title?: string; text?: string; action?: React.ReactNode }) {
  return <div className="state-box"><Inbox size={32} /><h2>{title}</h2><p>{text}</p>{action}</div>;
}

export function ErrorState({ onRetry }: { onRetry: () => void }) {
  return <div className="state-box error"><AlertTriangle size={32} /><h2>No pudimos cargar la información</h2><p>Verifica tu conexión e inténtalo de nuevo. Código: NET_SIM_01</p><button className="primary-button" onClick={onRetry}>Reintentar</button></div>;
}

export function Skeleton({ rows = 4 }: { rows?: number }) {
  return <div className="skeleton-wrap" aria-label="Cargando">{Array.from({ length: rows }, (_, i) => <i key={i} />)}</div>;
}

export function ConfirmDialog({ title, text, confirm, onClose, danger = false }: { title: string; text: string; confirm: () => void; onClose: () => void; danger?: boolean }) {
  return <Modal title={title} onClose={onClose}><div className="modal-body"><p>{text}</p><div className="modal-actions"><button className="secondary-button" onClick={onClose}>Cancelar</button><button className={danger ? "danger-button" : "primary-button"} onClick={() => { confirm(); onClose(); }}>Confirmar</button></div></div></Modal>;
}

export function Endpoint({ children }: { children: React.ReactNode }) { return <small className="endpoint">{children}</small>; }

export function IntegrityBadge({ verified }: { verified: boolean }) {
  return <span className={`integrity ${verified ? "ok" : "warn"}`}>{verified ? <CheckCircle2 size={13} /> : <AlertTriangle size={13} />}{verified ? "Integridad verificada" : "Sin verificar"}</span>;
}
