# PROMPT FIGMA — Supervisión Inteligente de Servicios en Campo

> Copia todo el contenido de este archivo (desde "ROL") y pégalo en Figma Make / Figma AI.

---

## ROL Y OBJETIVO

Actúa como un diseñador UX/UI senior de productos SaaS operativos. Diseña un sistema completo de **supervisión inteligente de servicios en campo** para una empresa de aseo que presta servicios en centros de costo (edificios, conjuntos residenciales, establecimientos).

El sistema resuelve un problema real: el coordinador de operaciones no puede comprobar de forma confiable que los supervisores visitan los centros de costo, ni conocer a tiempo los resultados de cada jornada. Hay quejas de clientes por ausencia de supervisores y las fotos sueltas no son prueba suficiente.

**Entregables:** dos productos conectados + un sistema de diseño.

1. **App móvil del Supervisor** (390×844, iOS/Android, *offline-first*).
2. **Panel web del Coordinador de operaciones** (1440×900, desktop).
3. **Design System** compartido (componentes, estilos, estados).

Idioma de toda la interfaz: **español (Colombia)**. Formato de fechas `dd/mm/aaaa`, hora 24 h, zona horaria America/Bogotá.

---

## PERSONAS

- **Supervisor de campo (móvil):** visita varios centros de costo al día, a menudo con poca o nula conexión, usa el teléfono de pie y con una mano. Necesita rapidez, botones grandes, pocos toques.
- **Coordinador de operaciones (web):** necesita visión general, alertas oportunas, evidencia confiable y reportes para responder a los clientes.

---

## PRINCIPIOS DE DISEÑO

- **Confianza y trazabilidad:** cada acción muestra quién, cuándo y dónde (fecha, hora, coordenadas).
- **Offline-first:** el estado de conexión y de sincronización es siempre visible en la app móvil; nunca se bloquea el trabajo por falta de internet.
- **Registro rápido en campo:** checklist con toggles grandes, dictado por voz, cámara en 1 toque, valores por defecto inteligentes.
- **Claridad operativa:** semáforo de estados consistente en móvil y web.
- **Accesibilidad:** contraste WCAG AA, objetivos táctiles ≥ 48 px, nunca usar solo color para comunicar estado (siempre ícono + texto).

---

## PALETA DE COLORES

Concepto: **confianza corporativa + frescura de limpieza + semáforo operativo claro**.

### Marca
| Rol | Nombre | HEX |
|---|---|---|
| Primario | Azul Control | `#0A3D62` |
| Primario hover/activo | Azul Profundo | `#082F4B` |
| Secundario (acento aseo) | Turquesa Limpio | `#0FA3B1` |
| Secundario claro | Aqua Suave | `#D4F1F4` |

### Neutros
| Rol | HEX |
|---|---|
| Fondo app | `#F4F8FB` |
| Superficie / tarjetas | `#FFFFFF` |
| Borde | `#E2E8F0` |
| Texto principal | `#1E293B` |
| Texto secundario | `#64748B` |
| Texto deshabilitado | `#A0AEC0` |

### Semánticos (estados)
| Estado | HEX | Fondo suave |
|---|---|---|
| Éxito / Cumplido / Sincronizado | `#2E9E6B` | `#E3F5EC` |
| Advertencia / Pendiente | `#F5A623` | `#FEF3DC` |
| Peligro / Crítico / Error | `#D64545` | `#FBE5E5` |
| Información / En curso | `#3B82F6` | `#E2EEFE` |
| Duplicado / Conflicto de sync | `#7C5CBF` | `#EEE9F8` |
| Sin conexión (offline) | `#475569` | `#E8ECF1` |

### Prioridad de novedades
Baja `#3B82F6` · Media `#F5A623` · Alta `#F97316` · **Crítica** `#D64545`

### Estados de visita
Programada `#64748B` · En curso `#3B82F6` · Completada `#2E9E6B` · Con novedades `#F97316` · Vencida / No realizada `#D64545` · Fuera de geocerca `#7C5CBF`

### Estados de sincronización
Pendiente `#F5A623` · Sincronizando `#3B82F6` · Sincronizado `#2E9E6B` · Error `#D64545` · Duplicado `#7C5CBF`

**Tipografía:** Poppins (títulos, 600/700) + Inter (cuerpo y datos, 400/500). Escala móvil 12/14/16/20/24/32; web 12/14/16/20/28/36.
**Grilla y forma:** base 8 pt, radios 12 px (tarjetas) y 8 px (inputs/botones), sombras suaves. Íconos Lucide, trazo 1.75 px.

---

## CANTIDAD IDEAL DE PÁGINAS: 32 FRAMES

Para cubrir absolutamente todos los puntos del documento sin pantallas de relleno: **13 pantallas móviles + 18 pantallas web + 1 portada con Design System = 32 frames**, más variantes de estado dentro de cada una (offline, error, vacío, cargando).

Organiza el archivo de Figma en estas páginas:

- `00 · Portada y Design System`
- `01 · App Supervisor (móvil)`
- `02 · Panel Coordinador (web)`
- `03 · Prototipo y Flujos`

### 01 · APP SUPERVISOR (13 pantallas)

| # | Pantalla | Contenido clave |
|---|---|---|
| M01 | Login | Identificación del supervisor (documento + PIN), biometría, sesión local que permite entrar sin internet |
| M02 | Mis visitas del día | Lista de visitas asignadas con estado, hora estimada, distancia; chip de conexión; contador de registros pendientes de sincronizar |
| M03 | Detalle del centro de costo | Dirección, mapa con geocerca, contacto, actividades contratadas a verificar, últimas visitas, botón **Check-in** |
| M04 | Check-in (validación de visita) | Captura de GPS (precisión en metros), verificación de geocerca (dentro / fuera), fecha y hora de llegada, foto de llegada con marca de agua, identificación del supervisor. Variantes: dentro del radio, fuera del radio, GPS débil, sin conexión |
| M05 | Checklist de supervisión | Actividades a verificar, cada una con **Cumple / No cumple / N.A.**, barra de progreso, acceso rápido a observación y foto |
| M06 | Detalle de actividad | Observación (texto + dictado por voz), fotos, información adicional relevante, calificación opcional |
| M07 | Evidencias | Cámara con marca de agua (fecha, hora, coordenadas, supervisor), galería de evidencias de la visita, estado de subida por archivo |
| M08 | Registrar novedad | Tipo, **prioridad** (baja/media/alta/crítica), descripción, evidencia, ubicación automática, aviso de que se notificará al coordinador |
| M09 | Resumen y Check-out | Resumen de cumplimiento, novedades registradas, observaciones finales, **Check-out** con GPS y hora de salida, duración total de la visita |
| M10 | Visita finalizada | Confirmación, estado de sincronización, siguiente visita sugerida |
| M11 | Centro de sincronización | Cola de pendientes, progreso, errores con motivo y botón **Reintentar**, indicador de integridad de datos, aviso de duplicado evitado |
| M12 | Historial y mis novedades | Visitas pasadas con estado de sync y novedades con su estado de seguimiento (Registrada → Cerrada), respuestas del coordinador |
| M13 | Perfil y ajustes | Datos del supervisor, almacenamiento local usado, permisos (GPS/cámara/notificaciones), sincronización automática, cierre de sesión |

**Elementos globales móviles:** barra de estado de conexión (En línea / Sin conexión / Sincronizando), tab bar inferior (Visitas · Sincronización · Historial · Perfil), toasts de confirmación.

### 02 · PANEL COORDINADOR (18 pantallas)

Layout: sidebar izquierdo colapsable (Azul Control), header con búsqueda global, campana de alertas con contador, filtro de fecha y avatar.

| # | Pantalla | Contenido clave |
|---|---|---|
| W01 | Login | Correo + contraseña, recuperación, doble factor opcional |
| W02 | Dashboard general | KPIs: visitas realizadas, visitas pendientes, supervisores activos, % de cumplimiento, novedades abiertas; gráfica de cumplimiento por día; mini-mapa; últimas alertas |
| W03 | Mapa en vivo | Supervisores activos con última ubicación, centros de costo con geocercas, color por estado de visita, panel lateral de detalle |
| W04 | Visitas | Tabla con filtros (estado, supervisor, centro de costo, fecha); pestañas Realizadas / En curso / Pendientes / Vencidas |
| W05 | Detalle de visita | Línea de tiempo (check-in → actividades → check-out), validación geográfica (mapa con punto vs. geocerca), checklist con resultados, evidencias, novedades asociadas, indicador de sincronización |
| W06 | Novedades | Bandeja en tabla y vista Kanban (Registrada · En revisión · En acción · Resuelta · Cerrada), filtros por prioridad |
| W07 | Detalle de novedad | Evidencias, historial de trazabilidad, **revisión del coordinador**, acción o decisión, asignación de responsable, comentarios, cierre con motivo |
| W08 | Centro de alertas | Alertas por tipo: visita no iniciada, check-in fuera de geocerca, check-out sin cerrar, visita demasiado corta, novedad crítica, sincronización fallida; marcar como atendida |
| W09 | Supervisores | Lista con estado (activo/inactivo), centros asignados, % de cumplimiento, última actividad |
| W10 | Perfil de supervisor | Historial de visitas, ruta del día, cumplimiento por período, novedades reportadas |
| W11 | Centros de costo | Lista con cliente, supervisor asignado, frecuencia de visita y % de cumplimiento |
| W12 | Detalle de centro de costo | Mapa y geocerca editable, historial de visitas, novedades, cumplimiento, supervisores asignados |
| W13 | Asignación y programación | Calendario semanal/mensual, asignar supervisor ↔ centro de costo, frecuencia, detección de visitas sin cubrir |
| W14 | Plantillas de actividades | Editor del checklist por centro de costo (actividades a verificar, obligatoriedad, evidencia requerida) |
| W15 | Generador de reportes | Selector: visitas realizadas, por supervisor, por centro de costo, novedades, cumplimiento, historial de visitas, evidencias; filtros por período |
| W16 | Vista previa y exportación | Vista previa del reporte con gráficas y tablas, exportar a PDF / Excel / CSV, programar envío |
| W17 | Evidencias | Galería filtrable (supervisor, centro de costo, fecha) con metadatos (hora, GPS, autor) e indicador de integridad |
| W18 | Configuración | Radio de geocerca, tiempo mínimo de visita, umbrales de alerta, usuarios y roles (Coordinador, Supervisor, Admin), canales de notificación |

### 00 · PORTADA Y DESIGN SYSTEM (1 frame)

Paleta, tipografía, íconos, botones (primario, secundario, peligro, deshabilitado), inputs, chips de estado (visita, novedad, sincronización, prioridad), tarjetas de visita, tabla, tarjetas KPI, modales, toasts, banners de conexión, marcadores de mapa y componentes de evidencia. Todo como componentes con variantes y *auto layout*.

---

## WORKFLOW A PROTOTIPAR (flujos conectados)

### Flujo A — Visita completa del supervisor
`M01 Login → M02 Mis visitas → M03 Detalle centro de costo → M04 Check-in (GPS + hora + foto) → M05 Checklist → M06 Detalle de actividad → M07 Evidencias → [si hay novedad] M08 Registrar novedad → M09 Resumen y Check-out → M10 Visita finalizada → M11 Sincronización`

### Flujo B — Operación sin conexión
1. Se pierde la conexión → banner gris "Sin conexión · tus datos se guardan en el dispositivo".
2. Todo lo registrado queda en almacenamiento local con estado **Pendiente**.
3. Regresa la conexión → sincronización automática (**Sincronizando**).
4. Resultado por registro: **Sincronizado**, **Error** (con motivo y Reintentar) o **Duplicado evitado**.
5. M11 muestra la cola, el progreso y el control de integridad.

Reglas a reflejar en UI: cada registro lleva un identificador único generado en el dispositivo (evita duplicidad), las evidencias llevan un hash de integridad, y los errores nunca eliminan datos locales.

### Flujo C — Gestión de novedades (según el documento)
`Visita → Identificación de novedad (M08) → Registro → Evidencia → Notificación al coordinador (W08) → Revisión del coordinador (W07) → Acción o decisión → Seguimiento → Cierre`

Estados de la novedad: **Registrada → Notificada → En revisión → En acción → Resuelta → Cerrada** (con opción **Reabierta**). El supervisor ve el estado y las respuestas en M12.

### Flujo D — Seguimiento del coordinador
`W01 Login → W02 Dashboard → (alerta) W08 → W05 Detalle de visita → W07 Detalle de novedad → W15 Generador → W16 Exportación`

### Flujo E — Planificación
`W13 Asignación y programación → W14 Plantillas de actividades → W12 Centro de costo → W09/W10 Supervisores`

### Ciclo de vida de una visita (estados)
`Programada → En curso (check-in) → Completada (check-out) → Sincronizada → Validada`
Rutas de excepción: **Vencida / No realizada** (nunca hubo check-in), **Fuera de geocerca** (alerta al coordinador), **Con novedades** (flujo C).

Configura el prototipo con transiciones *smart animate*, y crea variantes interactivas de M04 (dentro/fuera de geocerca) y de la barra de conexión (en línea / offline / sincronizando).

---

## BASE TECNOLÓGICA (el diseño debe contemplarla)

**Backend con JavaScript como base:** Node.js + Express (o NestJS), API REST en JSON, autenticación JWT con roles, WebSockets (Socket.IO) para alertas en tiempo real al panel, base de datos PostgreSQL con PostGIS para geocercas (o MongoDB), almacenamiento de evidencias en la nube, generación de reportes PDF/Excel en servidor.

**Frontend:** React para el panel web; app móvil como PWA o React Native, con IndexedDB y Service Workers para el modo offline.

Implicaciones para el diseño:

- Diseña **estados de carga, vacío y error** de cada pantalla (las respuestas de la API pueden fallar o tardar).
- Anota en cada pantalla clave el endpoint que la alimenta (por ejemplo: `POST /visitas/:id/checkin`, `POST /novedades`, `POST /sync/lote`, `GET /dashboard/kpis`, `GET /reportes?tipo=&desde=&hasta=`).
- Los campos de los formularios deben corresponder a un modelo de datos claro: **Usuario, Supervisor, CentroCosto, Geocerca, Visita, Actividad, ResultadoActividad, Evidencia, Novedad, Alerta, RegistroSync**.
- Tablas del panel con paginación, ordenamiento y filtros del lado del servidor.

---

## MATRIZ DE CUMPLIMIENTO (cada requisito del documento → pantalla)

| Requisito del documento | Pantallas |
|---|---|
| 3.1 Validación: geolocalización, check-in/out, fecha y hora, evidencia, identificación del supervisor | M01, M04, M07, M09, W05 |
| 3.2 Supervisión: consultar actividades, cumplidas / no cumplidas, observaciones, novedades, evidencias, info adicional | M03, M05, M06, M07, M08 |
| 3.3 Offline: almacenamiento local, sincronización, pendientes, errores, integridad, sin duplicados | M02, M11, banner global, Flujo B |
| 4. Panel: visitas realizadas/pendientes, supervisores activos/asignados, centros de costo, estados, novedades, evidencias, historial, indicadores, alertas, geografía | W02, W03, W04, W05, W08, W09, W11, W17 |
| 5. Novedades: registro, prioridad, evidencia, notificación, revisión, acción, seguimiento hasta cierre | M08, M12, W06, W07, W08 |
| 6. Reportes: visitas, por supervisor, por centro de costo, novedades, cumplimiento, historial, evidencias, períodos, exportación | W15, W16, W10, W12, W17 |
| Mecanismos adicionales propuestos | Geocerca configurable, tiempo mínimo de visita, foto con marca de agua, hash de integridad, alertas automáticas (W18, W08) |

---

## ENTREGA FINAL

- Los 32 frames organizados en las 4 páginas indicadas, con nombres `M01…M13` y `W01…W18`.
- Componentes y estilos (color, texto, efectos) publicados como librería.
- Prototipo navegable de los flujos A, B y C como mínimo.
- Estilo visual limpio y profesional, aire generoso, jerarquía clara, sin decoración innecesaria.
