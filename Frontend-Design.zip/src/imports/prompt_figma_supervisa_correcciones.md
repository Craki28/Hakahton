# PROMPT FIGMA MAKE — Supervisa: rutas reales, botones funcionales y pantallas faltantes

> Copia todo el contenido de este archivo (desde "ROL Y OBJETIVO") y pégalo en Figma Make **sobre el proyecto existente**. Es un prompt de **iteración**: no rehace el diseño, lo completa y lo corrige.

---

## ROL Y OBJETIVO

Actúa como un ingeniero front-end senior + diseñador UX/UI de productos SaaS operativos. Tienes abierto el proyecto **Supervisa** (panel web del Coordinador de operaciones para supervisión de servicios de aseo en campo). Hoy el proyecto tiene estos problemas:

1. **No hay router.** La navegación es un `useState("Dashboard")` en `App.tsx` y `Pages.tsx` pinta pantallas según un texto. No hay URLs, ni botón "atrás" del navegador, ni enlaces directos a un detalle.
2. **Hay botones sin acción** (Exportar, Nueva visita, los dos menús ⋯, Ver recursos, menú de usuario, ⌘K, selects de periodo y métrica).
3. **Hay botones que llevan a pantallas incompletas o inexistentes** (detalle de visita, detalle de novedad, perfil de supervisor, detalle de centro de costo, evidencias, plantillas, login, ayuda, vista previa de reportes, calendario de programación).
4. **Hay errores** (pantalla en blanco al cambiar de sección con una fila seleccionada, pestañas que se cruzan, toast que no se ve, dos estados distintos para las mismas alertas, contadores escritos a mano).

**Tu tarea:** corregir todo lo anterior y entregar un panel donde **cada botón, fila, enlace, tarjeta y menú tenga un destino o una acción real**, con rutas, estados de carga/vacío/error y datos coherentes entre pantallas.

**Idioma de toda la interfaz:** español (Colombia). Fechas `dd/mm/aaaa`, hora 24 h, zona horaria America/Bogotá. Números con coma decimal (`91,4%`).

---

## REGLAS DE ORO (leer antes de tocar nada)

1. **No rediseñes.** Conserva paleta, tipografía (Poppins títulos / Inter cuerpo), radios, sombras, iconos Lucide y las clases CSS existentes en `src/index.css` (`app-shell`, `sidebar`, `nav-item`, `topbar`, `page-heading`, `panel`, `panel-heading`, `kpi-card`, `table-wrap`, `status-chip`, `primary-button`, `secondary-button`, `text-button`, `plain-icon`, `split`, `detail`, `tabs`, `flow`, `thumbs`, `kv`, `toast`, `alert-row`, `drawer`). Si falta un estilo, agrégalo al final de `index.css` reutilizando los mismos tokens de color.
2. **Ningún botón sin acción.** Si un botón no puede hacer algo real, no debe existir. Si existe, debe: navegar, abrir un modal/menú/drawer, cambiar un estado o mostrar un toast de confirmación.
3. **Una sola fuente de verdad.** Todo el estado vive en un único store compartido (Context + `useReducer`). Prohibido mutar objetos globales (hoy `db.alerts[i].on = 1`, `n.e++`, `db.centers[sel][1] = …` mutan directamente).
4. **Dependencias:** solo se permite agregar `react-router-dom` (v7). Todo lo demás con React 19, Tailwind v4 y `lucide-react` que ya están instalados. Sin librerías de gráficas ni de mapas: se mantienen los gráficos hechos con CSS/SVG.
5. **Convenciones del proyecto:** componentes con `export default`, comillas dobles en strings con apóstrofes, JSX bien cerrado, TypeScript sin `any` en código nuevo.
6. **Accesibilidad:** contraste WCAG AA, objetivos táctiles/clic ≥ 40 px, foco visible, `aria-label` en botones de solo ícono, menús y modales cerrables con `Esc`, el foco vuelve al disparador al cerrar. Nunca comunicar estado solo con color: siempre ícono + texto (los `status-chip` ya llevan punto + texto).

---

## 1. ARQUITECTURA

### 1.1 Router

- Instala `react-router-dom` y usa **`HashRouter`** (funciona en el hosting estático de Figma Make sin configurar el servidor). Si por algún motivo no se puede instalar, implementa un mini-router propio basado en `window.location.hash` con el mismo mapa de rutas.
- Envuelve la app en `main.tsx`: `<HashRouter><StoreProvider><App/></StoreProvider></HashRouter>`.
- Usa `NavLink` en el sidebar (el resaltado "activo" lo da la ruta, no un `useState`). El botón **Configuración** del sidebar también debe resaltarse cuando la ruta es `/configuracion` (hoy no lo hace).
- Cada cambio de ruta: scroll al inicio de `.page`, cierra el menú móvil y limpia filtros locales de la pantalla anterior.
- `document.title` = `"{Pantalla} · Supervisa"`.
- Ruta no encontrada → pantalla **404** con botón "Volver al dashboard".
- Rutas protegidas: sin sesión → redirige a `/login` y, tras iniciar, regresa a la ruta que se pedía.

### 1.2 Mapa de rutas (cada una corresponde a una pantalla del documento original)

| Ruta | Pantalla | Código |
|---|---|---|
| `/login` | Inicio de sesión (+ recuperar contraseña) | W01 |
| `/` → `/dashboard` | Dashboard general | W02 |
| `/mapa` | Mapa en vivo | W03 |
| `/visitas` | Visitas (tabla con filtros y pestañas) | W04 |
| `/visitas/:id` | Detalle de visita | W05 |
| `/novedades` | Novedades (tabla + Kanban) | W06 |
| `/novedades/:id` | Detalle de novedad | W07 |
| `/alertas` | Centro de alertas | W08 |
| `/supervisores` | Supervisores | W09 |
| `/supervisores/:id` | Perfil de supervisor | W10 |
| `/centros` | Centros de costo | W11 |
| `/centros/:id` | Detalle de centro de costo | W12 |
| `/programacion` | Asignación y programación (calendario) | W13 |
| `/plantillas` y `/plantillas/:centroId` | Plantillas de actividades | W14 |
| `/reportes` | Generador de reportes | W15 |
| `/reportes/vista-previa` | Vista previa y exportación | W16 |
| `/evidencias` | Galería de evidencias | W17 |
| `/configuracion` | Configuración (parámetros, usuarios y roles, notificaciones) | W18 |
| `/perfil` | Mi perfil (coordinadora) | extra |
| `/ayuda` | Centro de ayuda | extra |
| `*` | 404 | extra |

Los filtros y pestañas se guardan en la URL con query params para poder compartir un enlace: `/visitas?estado=Vencida&supervisor=3`, `/novedades?vista=kanban&prioridad=Crítica`, `/reportes/vista-previa?tipo=cumplimiento&desde=2026-09-24&hasta=2026-10-01`.

### 1.3 Sidebar (menú lateral)

```
OPERACIÓN
  Dashboard · Mapa en vivo · Visitas · Novedades (contador) · Alertas (contador rojo)
GESTIÓN
  Supervisores · Centros de costo · Programación · Plantillas · Evidencias · Reportes
(abajo)
  Configuración
  Tarjeta "Centro de ayuda" → botón "Ver recursos" navega a /ayuda
```

- Se agregan **Plantillas** (icono `ClipboardList`) y **Evidencias** (icono `Image`) a GESTIÓN, porque hoy no tienen acceso.
- Sidebar **colapsable** en escritorio (botón `PanelLeftClose`/`PanelLeftOpen`; colapsado muestra solo iconos con tooltip) y drawer en móvil (ya existe, mantenerlo).
- Los contadores **se calculan desde el store**: Novedades = novedades no cerradas; Alertas = alertas no atendidas. Hoy están escritos a mano (`8` y `3`).

### 1.4 Estructura de archivos (dividir `Pages.tsx`)

```
src/
  main.tsx
  App.tsx                    (layout: sidebar + topbar + <Outlet/>, rutas)
  store/
    seed.ts                  (datos semilla, ver sección 7)
    reducer.ts               (acciones tipadas)
    StoreProvider.tsx        (Context + hooks useStore, useSelectors)
    api.ts                   (API simulada con retardo y errores simulados)
  components/
    Avatar.tsx StatusChip.tsx Modal.tsx Menu.tsx ConfirmDialog.tsx
    Toast.tsx Lightbox.tsx Skeleton.tsx EmptyState.tsx ErrorState.tsx
    DataTable.tsx Pagination.tsx PageHeader.tsx Tabs.tsx Breadcrumbs.tsx
    GeoMap.tsx               (mapa esquemático reutilizable)
    BarChart.tsx             (gráfica CSS/SVG reutilizable)
  pages/
    Login.tsx Dashboard.tsx LiveMap.tsx Visits.tsx VisitDetail.tsx
    Novelties.tsx NoveltyDetail.tsx Alerts.tsx Supervisors.tsx
    SupervisorProfile.tsx CostCenters.tsx CostCenterDetail.tsx
    Scheduling.tsx Templates.tsx Reports.tsx ReportPreview.tsx
    Evidences.tsx Settings.tsx Profile.tsx Help.tsx NotFound.tsx
```

Borra `Pages.tsx` cuando todo esté migrado.

---

## 2. CORRECCIÓN DE ERRORES (hacerlo primero)

| ID | Error actual | Corrección exacta |
|---|---|---|
| B1 | **Pantalla en blanco al cambiar de sección.** `sel` y `tab` de `Pages` persisten entre secciones. Abrir la fila 5 de Visitas y pasar a Supervisores deja `db.sups[4] === undefined` y la app se rompe. | Cada pantalla es un componente con su propio estado; al cambiar de ruta se desmonta. Los detalles se leen del id de la URL. Si el id no existe, mostrar **EmptyState "No encontramos este registro"** con botón para volver a la lista, nunca una excepción. |
| B2 | **Pestañas que se cruzan.** `tab` es compartido: quedarse en "En revisión" de Novedades y entrar a Visitas deja la tabla vacía. | Pestañas por pantalla, guardadas en query param. |
| B3 | **Toast invisible en Novedades.** Se llama `note("Estado actualizado")` pero esa pantalla no renderiza `{Toast}`. | Un único `ToastProvider` global en `App.tsx` con `useToast()`; todas las pantallas lo usan. Apilable (máx. 3), autocierre a 4 s, botón cerrar, `role="status"`. |
| B4 | **Alertas duplicadas.** El Dashboard usa `alerts` + `resolved` locales y `/Alertas` usa `db.alerts`; atender una no afecta a la otra. | Un solo arreglo `alertas` en el store con `atendidaPor` y `atendidaEn`. Dashboard, campana, drawer y Centro de alertas leen y escriben ahí. |
| B5 | **Contadores escritos a mano** (`8`, `3`, "2 críticas", "24 de 38", etc.). | Todos derivados del store con selectores (ver sección 7.3). |
| B6 | **El select de periodo no hace nada** (solo cambia el texto). | Filtra visitas, KPIs, gráfica y tabla del Dashboard por rango (ver 3.1). |
| B7 | **El buscador global solo filtra una tabla del Dashboard.** | Búsqueda global real (ver 3.2). |
| B8 | **El estado de novedades se muta con `n.e++`.** Falta *Notificada* y *Reabierta* que pide el documento. | Máquina de estados completa: `Registrada → Notificada → En revisión → En acción → Resuelta → Cerrada` y `Reabierta` (vuelve a "En revisión"). Cada cambio crea una entrada en el historial con autor, fecha, hora y comentario. |
| B9 | **Cambios de Configuración y de geocerca se aplican al mover el slider**, aunque exista botón Guardar. | Los controles editan un borrador local; solo "Guardar" confirma y escribe en el store; "Descartar" revierte. Si hay cambios sin guardar, mostrar badge "Cambios sin guardar" y confirmar al salir de la pantalla. |
| B10 | **El CSV exportado se ve mal en Excel** (tildes rotas). | Anteponer BOM `\uFEFF`, separador `;`, escapar comillas y saltos de línea, nombre `reporte-{tipo}-{aaaa-mm-dd}.csv`. |
| B11 | **Tabla de Centros** asocia supervisor con `db.visits[i].s` por índice (frágil). | Cada centro tiene `supervisorId` explícito. |
| B12 | **Fecha fija "18 de junio"** escrita en el código. | Calcular desde `new Date()` en America/Bogotá, con `Intl.DateTimeFormat("es-CO")`. |

---

## 3. BOTONES Y CONTROLES: COMPORTAMIENTO EXACTO

### 3.1 Dashboard (`/dashboard`)

| Elemento | Comportamiento |
|---|---|
| **Select de periodo** (Hoy / Ayer / Últimos 7 días / **Personalizado**) | Filtra todo el dashboard. "Personalizado" abre un popover con dos campos de fecha (desde / hasta) y botón "Aplicar". El periodo se guarda en la URL (`?periodo=7d`). Al cambiar, muestra *skeleton* 300 ms y recalcula KPIs, gráfica, tabla y mini-mapa. |
| **Exportar** | Abre un menú con 3 opciones: *CSV*, *Excel (.xls)*, *PDF (imprimir)*. CSV descarga el resumen del periodo con los KPIs; Excel genera una tabla HTML con `Content-Type: application/vnd.ms-excel`; PDF abre `window.print()` con una hoja de estilos `@media print` limpia (sin sidebar). Toast "Reporte exportado". Una opción final "Ir al generador de reportes" navega a `/reportes`. |
| **Nueva visita** | Abre el **modal "Programar visita"** (ver 5.1). Al guardar: agrega la visita al store, toast "Visita programada para {centro}", aparece de inmediato en la tabla y en Programación, y el KPI "Visitas pendientes" sube. |
| **Tarjetas KPI** (las 5) | Son clicables y navegan filtradas: Realizadas → `/visitas?estado=Completada`; Pendientes → `/visitas?estado=Pendiente`; Supervisores activos → `/supervisores?estado=activo`; Cumplimiento → `/reportes/vista-previa?tipo=cumplimiento`; Novedades abiertas → `/novedades?estado=abiertas`. Cursor pointer, foco visible, `role="link"`. |
| **Select "Métrica"** de la gráfica (Cumplimiento / Visitas) | Cambia los datos: *Cumplimiento* muestra porcentaje (eje 0–100 %), *Visitas* muestra conteo (eje 0–40). Tooltip al pasar el cursor/foco sobre cada barra con día, completadas, programadas y %. Clic en una barra → `/visitas?fecha=aaaa-mm-dd`. |
| **"Ver mapa"** | `/mapa`. |
| **Marcadores del mini-mapa** | Clic → `/mapa?seleccion={supervisorId}`. |
| **"Ver todas"** (Visitas de hoy) | `/visitas?fecha=hoy`. |
| **Fila de la tabla "Visitas de hoy"** | Clic en toda la fila → `/visitas/:id`. |
| **Botón ⋯ de cada fila** | Menú (`Menu` accesible): **Ver detalle** → `/visitas/:id` · **Reasignar supervisor** → modal pequeño con select de supervisor y botón Guardar · **Reprogramar** → modal con fecha y hora · **Ver centro de costo** → `/centros/:id` · **Cancelar visita** (solo si Pendiente; usa `ConfirmDialog` con motivo obligatorio). Cada acción actualiza el store y muestra toast. Debe detener la propagación para no disparar el clic de la fila. |
| **⋯ de "Actividad reciente"** | Menú: **Marcar todas como atendidas** (ConfirmDialog) · **Ver centro de alertas** → `/alertas` · **Configurar alertas** → `/configuracion#alertas`. |
| **Check ✔ de cada alerta** | Abre un mini-popover con campo opcional "Nota de atención" y botón "Marcar atendida". Actualiza el store (B4), baja los contadores del sidebar y de la campana, y permite **Deshacer** desde el toast durante 5 s. |
| **Clic en el cuerpo de una alerta** | Navega al origen: alerta de geocerca/visita → `/visitas/:id`; novedad crítica → `/novedades/:id`; sincronización → `/supervisores/:id`. |
| **"Ver centro de alertas"** | `/alertas`. |
| **Saludo** "Buenos días, Sofía" | Cambia según la hora (Buenos días / Buenas tardes / Buenas noches) y usa el nombre de la sesión. |
| **Estado de carga/vacío/error** | Al entrar: skeletons en KPIs, gráfica, tabla y lista de alertas (400–800 ms simulados). Si el periodo no tiene visitas → EmptyState "No hay visitas en este periodo" con botón "Programar visita". Si la API simulada falla → ErrorState con botón **Reintentar**. |

### 3.2 Barra superior (en todas las pantallas)

| Elemento | Comportamiento |
|---|---|
| **Botón menú (☰) móvil** | Ya funciona; añadir cierre con `Esc` y bloqueo de scroll del fondo. |
| **Búsqueda global** | Abre un **panel de resultados** debajo del input (y también al presionar `⌘K` / `Ctrl+K`, que enfoca el campo). Busca en visitas, supervisores, centros de costo, novedades y alertas, agrupado por tipo con icono. Navegable con flechas ↑↓, `Enter` abre el resultado, `Esc` cierra. Sin resultados: "No encontramos resultados para “{texto}”". Reemplaza el filtro actual solo sobre la tabla del Dashboard. La kbd muestra `Ctrl K` en Windows/Linux y `⌘ K` en Mac. |
| **"Actualizado ahora"** | Se vuelve un botón: clic = refrescar datos (skeleton breve y texto "Actualizado hace X s"). Se actualiza solo cada 30 s simulando tiempo real; si falla muestra "Sin conexión con el servidor" en estado `offline` (gris `#475569`). |
| **Campana** | Abre el drawer de alertas (ya existe). Contador = alertas no atendidas (no fijo en 3). Si es 0, se oculta el contador. El drawer debe mostrar **todas** las críticas y altas no atendidas (no solo `slice(0, 2)`), con check rápido para atender, enlace por alerta a su origen y botón "Revisar todas las alertas" → `/alertas`. Cierra con `Esc` y al hacer clic en el fondo. |
| **Perfil "Sofía Martínez ▾"** | Abre un menú: **Mi perfil** → `/perfil` · **Configuración** → `/configuracion` · **Centro de ayuda** → `/ayuda` · **Atajos de teclado** (modal con la lista) · separador · **Cerrar sesión** (ConfirmDialog → limpia la sesión → `/login` con toast "Sesión cerrada"). |

### 3.3 Sidebar y tarjeta de ayuda

- **Ver recursos** → `/ayuda`.
- El logo "Supervisa" → `/dashboard`.
- Tooltip con el nombre de cada ítem cuando el sidebar está colapsado.

### 3.4 Visitas (`/visitas`, W04)

- **Filtros** arriba de la tabla (en una barra): Estado, Supervisor, Centro de costo, Fecha (día o rango), buscador local. Chips de filtros activos con ✕ y botón "Limpiar filtros".
- **Pestañas** con contador: Todas · Realizadas (Completada) · En curso · Pendientes · Vencidas · Con novedad.
- **Tabla** con ordenamiento por columna (clic en encabezado, flecha ↑↓ y `aria-sort`), **paginación** (10/20/50 por página, "Mostrando 1–10 de 38"), y selección múltiple opcional con barra de acciones masivas (Reasignar, Exportar selección).
- **Botón Exportar** de la pantalla: exporta lo filtrado a CSV.
- **Botón "Nueva visita"**: mismo modal 5.1.
- **Fila** → `/visitas/:id`. Menú ⋯ por fila idéntico al del Dashboard.
- Cada fila muestra un chip de sincronización (Sincronizado / Pendiente / Error / Duplicado evitado) además del estado.

### 3.5 Detalle de visita (`/visitas/:id`, W05) — pantalla nueva

Cabecera: migas de pan `Visitas / {Centro}`, título, chip de estado, chip de sincronización, botones **Volver** y menú ⋯ (Reasignar, Reprogramar, Marcar como validada, Descargar informe PDF de la visita).

Contenido (rejilla de 2 columnas):
1. **Línea de tiempo** vertical: Programada → Check-in (hora, coordenadas, precisión en metros) → cada actividad con su resultado y hora → Check-out (hora, coordenadas) → Sincronizada → Validada. Pasos pendientes en gris con icono de reloj.
2. **Validación geográfica**: mapa esquemático con el círculo de la geocerca (radio configurado) y el punto de check-in; texto "Dentro de geocerca (12 m)" en verde o "FUERA de geocerca (340 m)" en morado/rojo con ícono ⚠️. Duración total vs. tiempo mínimo configurado (alerta si es menor).
3. **Checklist con resultados**: cada actividad con Cumple / No cumple / N.A., observación y miniaturas de evidencia. Las actividades obligatorias llevan una etiqueta.
4. **Evidencias**: galería; clic abre el **Lightbox** (ver 5.4) con metadatos (autor, fecha, hora, coordenadas, hash de integridad abreviado y badge "Integridad verificada").
5. **Novedades asociadas**: lista con prioridad y estado; clic → `/novedades/:id`; botón "Registrar novedad" abre un modal.
6. **Acciones del coordinador**: botón **Validar visita** (cambia estado a Validada, registra quién y cuándo), botón **Rechazar / pedir aclaración** (modal con motivo, notifica al supervisor), campo de **comentario interno**.

Estados: skeleton, "visita no encontrada", error con Reintentar.

### 3.6 Novedades (`/novedades`, W06)

- **Alternador de vista**: *Tabla* / *Kanban* (`?vista=kanban`). El Kanban tiene columnas Registrada · Notificada · En revisión · En acción · Resuelta · Cerrada con tarjetas (título, centro, chip de prioridad, responsable, antigüedad). Las tarjetas se pueden **arrastrar** entre columnas (HTML5 drag & drop) **y** cambiar con un menú ⋯ "Mover a…" (alternativa accesible). Mover pide un comentario opcional y registra el historial. No se puede saltar a "Cerrada" sin pasar por "Resuelta" (muestra toast explicando).
- **Filtros**: prioridad (Crítica / Alta / Media / Baja), estado, centro, supervisor, fecha. Pestañas con contador por estado.
- **Botón "Nueva novedad"** (coordinadores también pueden registrar): modal con tipo, prioridad, centro de costo, descripción y adjuntar evidencia (simulada).
- **Fila o tarjeta** → `/novedades/:id`.

### 3.7 Detalle de novedad (`/novedades/:id`, W07) — pantalla nueva

- Cabecera con título, chips de prioridad y estado, miga de pan, botón **Volver**.
- **Flujo de estados** (el componente `flow` actual, pero con los 7 estados) con el paso actual resaltado.
- **Datos**: centro, supervisor que reportó, visita de origen (enlace a `/visitas/:id`), fecha/hora, ubicación, descripción.
- **Evidencias** con Lightbox.
- **Revisión del coordinador**: formulario con *Decisión/acción* (select: Aceptar, Escalar al cliente, Solicitar más información, Descartar), *Responsable* (select de usuarios), *Fecha compromiso* y *Comentario*.
- **Botón de avance** "Pasar a «{siguiente estado}»": abre un modal que exige comentario al pasar a *Resuelta* y **motivo de cierre** (obligatorio) al pasar a *Cerrada*. Si está cerrada: botón **Reabrir** (motivo obligatorio) y el flujo muestra "Reabierta".
- **Historial de trazabilidad**: lista cronológica (quién, qué, cuándo) de todos los cambios y comentarios; campo para agregar comentario (visible para el supervisor en su app).
- Toast al actualizar (corrige B3).

### 3.8 Centro de alertas (`/alertas`, W08)

- **Pestañas por tipo con contador**: Todas · Visita no iniciada · Check-in fuera de geocerca · Check-out sin cerrar · Visita demasiado corta · Novedad crítica · Sincronización fallida.
- Filtros: estado (Pendientes / Atendidas), severidad, supervisor, fecha.
- Cada alerta: icono por tipo (con texto, no solo color), título, detalle, tiempo relativo, botón **Ver origen** (enlace según tipo) y botón **Marcar como atendida** (popover con nota). Selección múltiple + **"Atender seleccionadas"**.
- Las atendidas se muestran atenuadas con "Atendida por {nombre} · {fecha hora}" y botón **Reabrir**.
- Botón **"Configurar umbrales"** → `/configuracion#alertas`.
- Vacío: "Todo en orden: no hay alertas pendientes" con icono de check.

### 3.9 Supervisores (`/supervisores`, W09) y perfil (`/supervisores/:id`, W10)

**Lista:** columnas Supervisor (avatar + nombre), Estado (Activo/Inactivo, con chip), Centros asignados, % cumplimiento (con barra), Última actividad (tiempo relativo), Novedades. Filtros por estado y búsqueda; ordenamiento y paginación. Botón **"Nuevo supervisor"** (modal: nombre, documento, teléfono, centros asignados). Fila → `/supervisores/:id`. Menú ⋯: Ver perfil · Reasignar centros · Activar/Desactivar (ConfirmDialog).

**Perfil (nueva):** cabecera con avatar, nombre, estado, teléfono, última actividad y acciones (Reasignar centros, Desactivar). Secciones/pestañas: **Resumen** (KPIs del supervisor: cumplimiento del periodo, visitas, novedades), **Historial de visitas** (tabla con filtros por periodo; fila → `/visitas/:id`), **Ruta del día** (mapa esquemático con los centros en orden y la línea de recorrido), **Cumplimiento por periodo** (gráfica de barras semana/mes con selector), **Novedades reportadas** (lista; fila → `/novedades/:id`). Botón "Exportar historial" (CSV).

### 3.10 Centros de costo (`/centros`, W11) y detalle (`/centros/:id`, W12)

**Lista:** Centro, Cliente, Supervisor asignado, Frecuencia de visita (ej. "Diaria", "Lun-Mié-Vie"), Geocerca (m), % cumplimiento. Botón **"Nuevo centro de costo"** (modal con nombre, cliente, dirección, radio, frecuencia, supervisor). Fila → `/centros/:id`.

**Detalle (nueva):**
- Mapa esquemático con la **geocerca editable**: control de radio (slider 50–300 m + campo numérico) que redibuja el círculo en vivo; botones **Guardar geocerca** y **Descartar** (B9).
- **Historial de visitas** del centro (tabla, filtros, fila → `/visitas/:id`).
- **Novedades** del centro (lista → `/novedades/:id`).
- **Cumplimiento** (KPI + gráfica por semana).
- **Supervisores asignados** (lista con botón **Cambiar** → modal).
- Botón **"Editar plantilla de actividades"** → `/plantillas/:centroId`.

### 3.11 Programación (`/programacion`, W13)

- Alternador **Semana / Mes**, botones `‹` `›` y "Hoy" para navegar el calendario.
- **Calendario semanal** (columnas Lun–Dom, tarjetas por visita con hora, centro y avatar del supervisor). Clic en una tarjeta → panel lateral con el detalle, select para **cambiar supervisor** y botón **Reprogramar**. Clic en un hueco vacío → modal 5.1 con día/hora precargados.
- **Vista mensual** con puntos/contadores por día; clic en un día → vista semanal de ese día.
- **Detección de visitas sin cubrir:** banner superior "5 visitas sin supervisor asignado" con botón **"Resolver"** que abre una lista donde se asigna el supervisor a cada una (se sugiere el menos cargado). Las tarjetas sin cubrir se muestran con borde punteado, ícono ⚠️ y texto "Sin cubrir".
- Detección de **conflictos** (mismo supervisor, dos visitas con la misma hora): chip "Conflicto de horario" y bloqueo del guardado con mensaje.
- Panel/Botón **"Frecuencia"**: define la repetición por centro (diaria, días de la semana, semanal, quincenal) y genera las visitas del periodo.
- Cada asignación muestra toast "Asignación guardada" (y es **deshacible** 5 s).

### 3.12 Plantillas de actividades (`/plantillas` y `/plantillas/:centroId`, W14) — pantalla nueva

- `/plantillas`: lista de centros con su número de actividades y botón **Editar**.
- Editor: lista **ordenable** (botones ↑↓ y arrastrar) de actividades; por cada una: nombre, *obligatoria* (toggle), *evidencia requerida* (Ninguna / Foto / Foto + observación), descripción. Botones **Agregar actividad**, **Duplicar**, **Eliminar** (ConfirmDialog). Botón **"Copiar desde otro centro"** (select + confirmar). Vista previa lateral "Así lo verá el supervisor" (checklist con Cumple / No cumple / N.A.). **Guardar plantilla** / **Descartar** con detección de cambios sin guardar.
- La plantilla guardada es la que usa el detalle de visita para pintar el checklist.

### 3.13 Mapa en vivo (`/mapa`, W03)

- Mapa esquemático (reutiliza `GeoMap`) con **supervisores** (marcador con iniciales, color por estado de visita) y **centros de costo** (marcador de edificio con círculo de geocerca).
- **Filtros** (chips): En visita · En traslado · Con novedad · Fuera de geocerca · Vencida. Leyenda con ícono + texto.
- Clic en un marcador → **panel lateral** (`detail`) con nombre, estado, última ubicación y hora, geovalidación, y botones **Ver visita** → `/visitas/:id`, **Ver perfil** → `/supervisores/:id`. Si el panel está cerrado, el mapa ocupa todo el ancho. `Esc` cierra el panel.
- Controles de zoom `+` `−` y "Centrar" (aplican una transformación CSS al lienzo), y botón **"Mostrar geocercas"** (toggle).
- Lista lateral de supervisores activos con búsqueda; clic en uno centra y selecciona su marcador.
- Soporta `?seleccion=` desde otros lugares.

### 3.14 Reportes (`/reportes`, W15) y vista previa (`/reportes/vista-previa`, W16)

**Generador (W15):** tarjetas seleccionables por tipo — Visitas realizadas, Por supervisor, Por centro de costo, Novedades, Cumplimiento, Historial de visitas, Evidencias. Panel de filtros: periodo (Hoy / 7 días / 30 días / Mes actual / Personalizado), supervisor(es), centro(s) de costo, estado. Botón **"Generar vista previa"** (deshabilitado hasta elegir tipo y periodo) → `/reportes/vista-previa?...`. Lista **"Reportes recientes"** y **"Envíos programados"**.

**Vista previa y exportación (W16):** muestra el reporte con **resumen de KPIs, gráfica y tabla** (paginada). Botones: **Exportar PDF** (`window.print()` con hoja de impresión limpia, con encabezado y pie "Generado el dd/mm/aaaa hh:mm por {usuario}"), **Exportar Excel** (.xls), **Exportar CSV** (BOM, B10), **Programar envío** (modal: frecuencia diaria/semanal/mensual, día y hora, destinatarios por correo con validación de formato, formato del archivo) y **Volver a filtros**. El envío programado queda en la lista del generador. Indicador "N registros incluidos".

### 3.15 Evidencias (`/evidencias`, W17) — pantalla nueva

- Galería en grilla con miniaturas generadas (bloques de color o patrón con icono de cámara; no usar imágenes externas), sobre cada una: centro, supervisor, fecha y hora, y badge de integridad ("Verificada" ✔ / "Sin verificar" ⚠️).
- **Filtros**: supervisor, centro de costo, fecha, tipo (llegada, actividad, novedad). Orden por fecha. Carga progresiva ("Cargar más").
- Clic → **Lightbox** (5.4) con metadatos completos: autor, fecha, hora, coordenadas, precisión, hash SHA-256 abreviado (con botón **Copiar hash**), enlace a la visita y a la novedad, **Descargar** y navegación ←/→.
- Selección múltiple + **"Descargar selección"**.

### 3.16 Configuración (`/configuracion`, W18)

Secciones con navegación interna por anclas (`#parametros`, `#alertas`, `#usuarios`, `#notificaciones`) y pestañas:
1. **Parámetros de validación**: radio de geocerca por defecto (50–300 m), tiempo mínimo de visita (5–60 min), precisión mínima de GPS (m), frecuencia de sincronización.
2. **Umbrales de alerta**: minutos de tolerancia para "visita no iniciada", "check-out sin cerrar" y "visita demasiado corta"; toggle por tipo de alerta (el toggle "Alertas automáticas" actual pasa a ser el interruptor general).
3. **Usuarios y roles**: tabla (nombre, correo, rol Coordinador / Supervisor / Admin, estado) con **Invitar usuario** (modal), **Editar rol** (select), **Desactivar** (ConfirmDialog). No permitir que el último Admin se desactive.
4. **Canales de notificación**: toggles de Correo, Push, WhatsApp, Panel; destinatarios por severidad.
5. Guardado con borrador, **Guardar** / **Descartar**, "Cambios sin guardar" (B9). Al guardar, los parámetros se reflejan en las validaciones (por ejemplo, el radio por defecto se usa en "Nuevo centro" y el tiempo mínimo marca visitas "demasiado cortas").
6. Bloque "Herramientas de demostración" (plegado): interruptor "Simular error de red" y "Simular lentitud", para probar los estados de carga y error.

### 3.17 Login (`/login`, W01) — pantalla nueva

Pantalla centrada, sin sidebar ni topbar. Campos: correo y contraseña (con botón mostrar/ocultar), checkbox "Recordarme", **Iniciar sesión**, enlace **"¿Olvidaste tu contraseña?"** (cambia a un paso de recuperación con campo de correo + botón **Enviar enlace** + mensaje de confirmación + **Volver**), y bloque opcional de **doble factor** (6 casillas para código, "Reenviar código" con cuenta regresiva de 30 s). Validación en línea (formato de correo, campos obligatorios, mensajes bajo cada campo), estado de carga en el botón, error "Credenciales incorrectas" tras 3 intentos con bloqueo simulado de 30 s. Credenciales de demostración visibles en una nota: `sofia@supervisa.co` / `Demo2026!`.

### 3.18 Mi perfil (`/perfil`) y Ayuda (`/ayuda`) — pantallas nuevas

- **Perfil:** datos de la coordinadora (editable: nombre, teléfono, foto con iniciales), cambiar contraseña (modal), preferencias (idioma fijo es-CO, zona horaria America/Bogotá, notificaciones). Botón **Guardar** y **Cerrar sesión**.
- **Ayuda:** buscador de guías, tarjetas por tema (Primeros pasos, Visitas, Novedades, Reportes, Configuración), **preguntas frecuentes** en acordeón, tabla de **atajos de teclado**, y tarjeta de **contacto de soporte** (correo `soporte@supervisa.co`, teléfono, horario) con botón **"Escribir a soporte"** que abre un modal con asunto y mensaje (simula el envío y muestra toast).

### 3.19 Pantalla 404

Ícono, "No encontramos esta página", botón **Volver al dashboard** y enlace **Atrás**.

---

## 4. ESTADOS DE CARGA, VACÍO Y ERROR (en TODAS las pantallas)

Implementa los tres componentes y úsalos en cada pantalla y en cada panel con datos:

- **Skeleton:** bloques grises animados con las mismas dimensiones que el contenido real (evitar saltos de layout). Duración simulada 300–800 ms.
- **EmptyState:** icono Lucide, título, una frase de ayuda y un botón de acción coherente (por ejemplo "Limpiar filtros" o "Programar visita").
- **ErrorState:** icono de alerta, mensaje claro, código técnico discreto, botón **Reintentar** y enlace "Ir al dashboard".

Capa `api.ts`: cada función (`getKpis`, `getVisitas`, `getNovedades`, `postCheckin`, `patchNovedad`, `getReporte`, etc.) devuelve una `Promise` con retardo aleatorio y puede fallar si el interruptor "Simular error de red" está activo. Cada pantalla clave muestra, en pequeño y gris al pie, el endpoint que la alimenta, por ejemplo: `GET /dashboard/kpis`, `GET /visitas?estado=&supervisor=&desde=&hasta=`, `PATCH /novedades/:id/estado`, `GET /reportes?tipo=&desde=&hasta=`.

Tablas: **paginación, ordenamiento y filtros** que reproducen el comportamiento "del lado del servidor" (la función de `api.ts` recibe página, orden y filtros y devuelve `{ items, total }`).

---

## 5. COMPONENTES COMPARTIDOS (crear una sola vez y reutilizar)

### 5.1 Modal "Programar visita"
Campos: **Centro de costo** (select), **Supervisor** (select, con sugerencia del que tiene menos carga y aviso si está en conflicto), **Fecha** (por defecto hoy), **Hora**, **Repetición** (Una vez / Diaria / Semanal), **Notas**. Validación en línea con mensajes; botones **Cancelar** y **Programar visita** (deshabilitado hasta ser válido). Al guardar cierra, muestra toast y navega opcionalmente con "Ver en programación".

### 5.2 `Modal` y `ConfirmDialog`
Fondo oscuro con `scrim`, `role="dialog"`, `aria-modal`, trampa de foco, cierre con `Esc` y clic fuera (salvo si hay cambios sin guardar). `ConfirmDialog` admite variante peligro (botón rojo `#D64545`) y campo opcional "motivo".

### 5.3 `Menu` (menú contextual ⋯ y menú de usuario)
Botón disparador con `aria-haspopup`/`aria-expanded`, lista con `role="menu"`, navegación con flechas, cierre con `Esc` y clic fuera, posicionado para no salirse de la pantalla.

### 5.4 `Lightbox` (visor de evidencias)
Imagen grande (la miniatura generada, escalada), panel de metadatos (autor, fecha, hora, coordenadas, precisión, hash, integridad), botones Anterior/Siguiente (también con ←/→), **Descargar**, **Copiar hash**, **Cerrar**.

### 5.5 `Toast`
Un solo proveedor, apilable, con botón opcional **Deshacer**, variantes éxito/info/advertencia/error (icono + texto).

### 5.6 `DataTable`
Encabezados ordenables, filas clicables con foco/teclado (`Enter`), selección múltiple opcional, paginación, estados de carga/vacío/error integrados y soporte responsive (en móvil se transforma en tarjetas apiladas).

### 5.7 Otros
`Breadcrumbs`, `Tabs` (con contador y sincronización con la URL), `PageHeader`, `Avatar`, `StatusChip` (con las 4 familias: estado de visita, prioridad, estado de novedad, sincronización), `BarChart`, `GeoMap`, `Tooltip`.

---

## 6. RESPONSIVE

- ≥1200 px: sidebar fijo (colapsable) + contenido.
- 768–1199 px: sidebar colapsado a iconos; los paneles `split` pasan a una sola columna (el detalle aparece debajo o como drawer).
- <768 px: sidebar como drawer; tablas → tarjetas; modales a pantalla completa; filtros en un panel desplegable.
- Ningún scroll horizontal del cuerpo de la página (las tablas anchas scrollean dentro de su contenedor).

---

## 7. DATOS: MODELO, SEMILLA Y SELECTORES

### 7.1 Modelo (tipos TypeScript)
`Usuario`, `Supervisor`, `CentroCosto`, `Geocerca`, `Visita`, `Actividad`, `ResultadoActividad`, `Evidencia`, `Novedad`, `EntradaHistorial`, `Alerta`, `RegistroSync`, `Configuracion`, `EnvioProgramado`. Todos con `id` único (UUID o prefijo + número) y fechas ISO. Reglas del documento original que deben reflejarse: cada registro lleva un **identificador único generado en el dispositivo** (evita duplicados), las evidencias llevan un **hash de integridad** y los errores de sincronización **nunca eliminan datos locales**.

### 7.2 Semilla (`seed.ts`)
- **5 centros de costo:** Torre Empresarial 93, Conjunto Bosques del Norte, Centro Comercial Altavista, Edificio Parque Central, Clínica San Rafael, con cliente, dirección, coordenadas, radio, frecuencia, `supervisorId` y plantilla de actividades.
- **12 supervisores** (9 activos, 3 inactivos) incluyendo Laura Gómez, Carlos Ruiz, Andrea Melo y Miguel Torres.
- **Visitas:** ≈38 para hoy (las 5 conocidas primero, con los mismos estados y horas que hoy: Completada, En curso, Con novedad, Pendiente, Vencida) y entre 30 y 40 por cada uno de los 6 días anteriores, generadas con una función determinista (misma semilla = mismos datos) para que gráfica, KPIs y tablas coincidan.
- **Novedades:** ≥12 en distintos estados y prioridades, con historial y evidencias.
- **Alertas:** ≥10 de los 6 tipos, algunas atendidas.
- **Evidencias:** ≥30 con hash, autor, hora y coordenadas.
- **Usuarios:** ≥6 con roles distintos.

### 7.3 Selectores derivados (nada escrito a mano)
`visitasRealizadas`, `visitasProgramadas`, `visitasPendientes`, `visitasPorIniciar`, `supervisoresActivos`, `supervisoresEnVisita`, `cumplimientoGlobal`, `cumplimientoPorDia`, `novedadesAbiertas`, `novedadesCriticas`, `alertasSinAtender`, `visitasSinCubrir`, `conflictosDeHorario`, `cumplimientoPorSupervisor`, `cumplimientoPorCentro`. Los contadores del sidebar, campana, KPIs y pestañas salen de aquí.

### 7.4 Persistencia
Guardar el store en `localStorage` (con try/catch) para que los cambios sobrevivan a un refresco; botón "Restablecer datos de demostración" en Configuración → Herramientas de demostración (ConfirmDialog).

---

## 8. FLUJOS QUE DEBEN QUEDAR CONECTADOS DE PUNTA A PUNTA

1. **Seguimiento (D):** Login → Dashboard → alerta (clic) → Detalle de visita → Detalle de novedad → Generador de reportes → Vista previa → Exportar.
2. **Planificación (E):** Programación → Plantillas → Detalle de centro → Supervisores / Perfil de supervisor.
3. **Atención de alerta:** Campana → drawer → atender alerta → los contadores del sidebar, campana, KPI y Centro de alertas bajan a la vez.
4. **Gestión de novedad (C):** Novedad nueva → Notificada → En revisión (con responsable) → En acción → Resuelta → Cerrada (con motivo) → Reabrir; cada paso aparece en el historial y en el KPI "Novedades abiertas".
5. **Nueva visita:** Dashboard → Nueva visita → aparece en Programación, Visitas, tabla del Dashboard y KPI de pendientes.

---

## 9. CRITERIOS DE ACEPTACIÓN (verifica uno por uno antes de terminar)

- [ ] Todas las rutas de la sección 1.2 cargan por URL directa y con el botón Atrás/Adelante del navegador.
- [ ] Ningún botón, fila, tarjeta KPI, marcador, miniatura o ícono interactivo queda sin acción.
- [ ] **Exportar**, **Nueva visita**, los dos ⋯, **Ver recursos**, el menú de usuario, `⌘K/Ctrl K`, el select de periodo y el select de métrica funcionan como se describe.
- [ ] Cambiar de sección con una fila seleccionada **nunca** deja la pantalla en blanco (B1) y las pestañas no se cruzan (B2).
- [ ] Todos los toasts son visibles en todas las pantallas (B3).
- [ ] Atender una alerta en cualquier lugar actualiza todos los contadores (B4, B5).
- [ ] El periodo del Dashboard cambia KPIs, gráfica y tabla (B6).
- [ ] Búsqueda global devuelve resultados de varias entidades y navega (B7).
- [ ] Las novedades recorren los 7 estados con historial (B8).
- [ ] Configuración y geocercas solo cambian al pulsar **Guardar** (B9).
- [ ] El CSV abre correctamente en Excel con tildes (B10).
- [ ] La fecha mostrada es la real, no "18 de junio" (B12).
- [ ] Cada pantalla tiene estados de carga, vacío y error probados con el interruptor de error de red.
- [ ] Navegación completa solo con teclado y foco visible; modales y menús se cierran con `Esc`.
- [ ] Sin scroll horizontal en 390, 768 y 1440 px.
- [ ] `pnpm build` termina sin errores de TypeScript.

---

## 10. LO QUE NO DEBES HACER

- No cambiar la paleta, la tipografía ni el estilo visual existentes.
- No agregar librerías (solo `react-router-dom`).
- No dejar botones decorativos "para después".
- No mutar objetos globales ni usar `any` en código nuevo.
- No usar imágenes externas ni datos aleatorios que cambien en cada recarga.
- No eliminar datos al fallar una sincronización simulada.
- No pedir confirmación en acciones reversibles que ya ofrecen **Deshacer**.

---

## ENTREGA FINAL

El proyecto Supervisa actualizado, con router, store único, los 21 destinos de la sección 1.2, los componentes compartidos de la sección 5 y los criterios de aceptación de la sección 9 cumplidos. Al terminar, resume en una lista corta qué cambió y qué rutas nuevas existen.
