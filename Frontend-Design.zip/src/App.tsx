import { useEffect, useMemo, useRef, useState } from "react";
import { Link, NavLink, Outlet, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import {
  BarChart3, Bell, Building2, CalendarDays, ChevronDown, ChevronRight, CircleAlert, ClipboardList, HelpCircle,
  Image, LayoutDashboard, Map, Menu, PanelLeftClose, PanelLeftOpen, Search, Settings, ShieldCheck, Sparkles, Users, X,
} from "lucide-react";
import { Avatar } from "./components";
import { useMetrics, useStore, useToast } from "./store";
import {
  AlertsPage, CenterDetail, Centers, Dashboard, EvidencePage, Help, LiveMap, Login, NotFound, Novelties,
  NoveltyDetail, Profile, Protected, ReportPreview, Reports, Scheduling, SettingsPage, SupervisorDetail,
  Supervisors, Templates, VisitDetail, Visits,
} from "./screens";

const nav = [
  ["OPERACIÓN", [
    ["/dashboard", "Dashboard", LayoutDashboard], ["/mapa", "Mapa en vivo", Map], ["/visitas", "Visitas", CalendarDays],
    ["/novedades", "Novedades", CircleAlert], ["/alertas", "Alertas", Bell],
  ]],
  ["GESTIÓN", [
    ["/supervisores", "Supervisores", Users], ["/centros", "Centros de costo", Building2], ["/programacion", "Programación", CalendarDays],
    ["/plantillas", "Plantillas", ClipboardList], ["/evidencias", "Evidencias", Image], ["/reportes", "Reportes", BarChart3],
  ]],
] as const;

const titleByPath: Record<string, string> = { dashboard: "Dashboard", mapa: "Mapa en vivo", visitas: "Visitas", novedades: "Novedades", alertas: "Alertas", supervisores: "Supervisores", centros: "Centros de costo", programacion: "Programación", plantillas: "Plantillas", evidencias: "Evidencias", reportes: "Reportes", configuracion: "Configuración", perfil: "Mi perfil", ayuda: "Ayuda" };

function Layout() {
  const { state, dispatch } = useStore(); const metrics = useMetrics(); const navigate = useNavigate(); const location = useLocation(); const toast = useToast();
  const [mobile, setMobile] = useState(false); const [collapsed, setCollapsed] = useState(false); const [query, setQuery] = useState(""); const [alertsOpen, setAlertsOpen] = useState(false); const [profileOpen, setProfileOpen] = useState(false); const input = useRef<HTMLInputElement>(null);
  useEffect(() => {
    setMobile(false); setAlertsOpen(false); setProfileOpen(false); setQuery(""); document.querySelector(".page")?.scrollTo(0, 0);
    const key = location.pathname.split("/")[1] || "dashboard"; document.title = `${titleByPath[key] || "Página"} · Supervisa`;
  }, [location.pathname]);
  useEffect(() => { const handler = (event: KeyboardEvent) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") { event.preventDefault(); input.current?.focus(); } if (event.key === "Escape") { setMobile(false); setAlertsOpen(false); setProfileOpen(false); setQuery(""); } }; document.addEventListener("keydown", handler); return () => document.removeEventListener("keydown", handler); }, []);
  const results = useMemo(() => query.length < 2 ? [] : [
    ...state.visits.map((v) => ({ type: "Visita", label: state.centers.find((c) => c.id === v.centerId)?.name || "", to: `/visitas/${v.id}` })),
    ...state.supervisors.map((s) => ({ type: "Supervisor", label: s.name, to: `/supervisores/${s.id}` })),
    ...state.centers.map((c) => ({ type: "Centro", label: c.name, to: `/centros/${c.id}` })),
    ...state.novelties.map((n) => ({ type: "Novedad", label: n.title, to: `/novedades/${n.id}` })),
  ].filter((item) => item.label.toLowerCase().includes(query.toLowerCase())).slice(0, 8), [query, state]);
  const attend = (id: string) => { dispatch({ type: "ATTEND_ALERT", id, attended: true }); toast.push("Alerta atendida", { label: "Deshacer", run: () => dispatch({ type: "ATTEND_ALERT", id, attended: false }) }); };
  return <div className={`app-shell ${collapsed ? "sidebar-collapsed" : ""}`}>{mobile && <div className="scrim" onClick={() => setMobile(false)}/>}
    <aside className={`sidebar ${mobile ? "open" : ""}`}><Link className="brand" to="/dashboard"><div className="brand-mark"><ShieldCheck size={24}/></div><div><strong>Supervisa</strong><span>Control operativo</span></div></Link><button className="icon-button collapse-button" onClick={() => setCollapsed(!collapsed)} aria-label={collapsed ? "Expandir menú" : "Contraer menú"}>{collapsed ? <PanelLeftOpen size={18}/> : <PanelLeftClose size={18}/>}</button><button className="icon-button close-mobile" onClick={() => setMobile(false)}><X size={20}/></button>
      <nav className="main-nav">{nav.map(([section, items]) => <div key={section}><span className="nav-label">{section}</span>{items.map(([to,label,Icon]) => <NavLink title={label} key={to} to={to} className={({isActive}) => `nav-item ${isActive ? "active" : ""}`}><Icon size={19}/><span>{label}</span>{label === "Novedades" && <b>{metrics.openNovelties}</b>}{label === "Alertas" && metrics.unattendedAlerts > 0 && <b className="danger-count">{metrics.unattendedAlerts}</b>}</NavLink>)}</div>)}</nav>
      <div className="sidebar-bottom"><NavLink to="/configuracion" className={({isActive}) => `nav-item ${isActive ? "active" : ""}`}><Settings size={19}/><span>Configuración</span></NavLink><div className="support-card"><Sparkles size={18}/><strong>Centro de ayuda</strong><span>Encuentra guías y soporte</span><Link to="/ayuda">Ver recursos <ChevronRight size={14}/></Link></div></div>
    </aside>
    <main className="main-content"><header className="topbar"><button className="icon-button menu-mobile" onClick={() => setMobile(true)}><Menu size={21}/></button><div className="global-search"><label className="search-box"><Search size={18}/><input ref={input} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar visita, supervisor o centro..."/><kbd>Ctrl K</kbd></label>{query.length >= 2 && <div className="search-results">{results.length ? results.map((r,i) => <button key={`${r.to}-${i}`} onClick={() => navigate(r.to)}><span>{r.type}</span><strong>{r.label}</strong><ChevronRight size={15}/></button>) : <p>No encontramos resultados para “{query}”</p>}</div>}</div>
      <div className="topbar-actions"><button className="live-pill" onClick={() => toast.push("Información actualizada")}><span/> Actualizado ahora</button><button className="notification-button" onClick={() => setAlertsOpen(!alertsOpen)} aria-expanded={alertsOpen}><Bell size={20}/>{metrics.unattendedAlerts > 0 && <span>{metrics.unattendedAlerts}</span>}</button><button className="user-profile" onClick={() => setProfileOpen(!profileOpen)} aria-expanded={profileOpen}><Avatar initials="SM"/><div><strong>{state.session.name}</strong><span>Coordinadora</span></div><ChevronDown size={15}/></button></div>
      {alertsOpen && <div className="header-pop drawer-pop"><div className="drawer-heading"><div><span>ALERTAS</span><h2>Atención requerida</h2></div><button className="icon-button" onClick={() => setAlertsOpen(false)}><X size={18}/></button></div>{state.alerts.filter((a) => !a.attended && a.severity !== "Media").map((a) => <div className="drawer-alert" key={a.id}><button className="alert-icon critical" onClick={() => navigate(a.origin)}><Bell size={16}/></button><button className="drawer-alert-body" onClick={() => navigate(a.origin)}><strong>{a.title}</strong><p>{a.detail}</p></button><button className="plain-icon" aria-label="Atender" onClick={() => attend(a.id)}>✓</button></div>)}<Link className="primary-button full-button" to="/alertas">Revisar todas las alertas</Link></div>}
      {profileOpen && <div className="header-pop profile-menu"><Link to="/perfil">Mi perfil</Link><Link to="/configuracion">Configuración</Link><Link to="/ayuda">Centro de ayuda</Link><button onClick={() => toast.push("Atajos: Ctrl K buscar · Esc cerrar paneles")}>Atajos de teclado</button><hr/><button className="danger-text" onClick={() => {dispatch({type:"LOGOUT"});navigate("/login");toast.push("Sesión cerrada");}}>Cerrar sesión</button></div>}
    </header><div className="page"><Outlet/></div></main>
  </div>;
}

export default function App() {
  return <Routes>
    <Route path="/login" element={<Login/>}/>
    <Route path="/" element={<Protected><Layout/></Protected>}>
      <Route index element={<NavigateToDashboard/>}/><Route path="dashboard" element={<Dashboard/>}/><Route path="mapa" element={<LiveMap/>}/>
      <Route path="visitas" element={<Visits/>}/><Route path="visitas/:id" element={<VisitDetail/>}/><Route path="novedades" element={<Novelties/>}/><Route path="novedades/:id" element={<NoveltyDetail/>}/>
      <Route path="alertas" element={<AlertsPage/>}/><Route path="supervisores" element={<Supervisors/>}/><Route path="supervisores/:id" element={<SupervisorDetail/>}/>
      <Route path="centros" element={<Centers/>}/><Route path="centros/:id" element={<CenterDetail/>}/><Route path="programacion" element={<Scheduling/>}/>
      <Route path="plantillas" element={<Templates/>}/><Route path="plantillas/:centerId" element={<Templates/>}/><Route path="reportes" element={<Reports/>}/><Route path="reportes/vista-previa" element={<ReportPreview/>}/>
      <Route path="evidencias" element={<EvidencePage/>}/><Route path="configuracion" element={<SettingsPage/>}/><Route path="perfil" element={<Profile/>}/><Route path="ayuda" element={<Help/>}/><Route path="*" element={<NotFound/>}/>
    </Route>
  </Routes>;
}
function NavigateToDashboard() { const navigate = useNavigate(); useEffect(() => navigate("/dashboard", { replace: true }), [navigate]); return null; }
